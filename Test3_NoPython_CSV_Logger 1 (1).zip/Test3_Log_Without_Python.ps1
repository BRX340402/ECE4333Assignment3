# ECE 4333 Assignment 3 Test 3 - Windows PowerShell 5.1+ CSV logger
# Read-only Wi-Fi logger: does NOT issue motor, settings, or control commands.
param(
  [ValidateRange(1,7200)][int]$Seconds = 120,
  [ValidateRange(300,10000)][int]$IntervalMs = 800,
  [string]$Url = 'http://192.168.4.1/traffic-status',
  [string]$Out = 'run01'
)
$ErrorActionPreference = 'Stop'
$folder = Split-Path -Parent $MyInvocation.MyCommand.Definition
$prefix = Join-Path $folder $Out
$poseCsv = "${prefix}_pose.csv"
$eventsCsv = "${prefix}_events.csv"
$rawJsonl = "${prefix}_raw.jsonl"
foreach ($p in @($poseCsv, $eventsCsv, $rawJsonl)) {
  if (Test-Path -LiteralPath $p) { Remove-Item -LiteralPath $p -Force }
}
$watch = [Diagnostics.Stopwatch]::StartNew()
$previousUT = $null
$runStartUT = $null
$previousEvent = $null
$count = 0
$warningCount = 0
Write-Host "Robot logger: $Seconds seconds | $Url"
Write-Host 'Requires connection to ECE4333_A2_V2 Wi-Fi; does not control the motors.'
Write-Host "Writing to $folder"
while ($watch.Elapsed.TotalSeconds -lt $Seconds) {
  try {
    $status = Invoke-RestMethod -Uri $Url -TimeoutSec 4 -Headers @{ 'Cache-Control'='no-cache' }
    $u = $status.uno
    if ($null -eq $u -or $null -eq $u.UT) { throw 'UNO telemetry has not arrived' }
    $ut = [long]$u.UT
    $age = [int]$status.age_ms
    if (($null -eq $previousUT -or $previousUT -ne $ut) -and $age -lt 1500) {
      $previousUT = $ut
      $mode = [int]$u.M
      if ($mode -eq 6 -and $null -eq $runStartUT) { $runStartUT = $ut }
      $runT = ''
      if ($null -ne $runStartUT) { $runT = [math]::Round(($ut - $runStartUT)/1000.0,3) }
      $r=$status.objects.red; $g=$status.objects.green; $s=$status.objects.stop
      $redSeen = [int]([bool]($r.valid -and $r.seen))
      $greenSeen = [int]([bool]($g.valid -and $g.seen))
      $stopSeen = [int]([bool]($s.valid -and $s.seen))
      $row = [pscustomobject][ordered]@{
        pc_elapsed_s=[math]::Round($watch.Elapsed.TotalSeconds,3)
        run_t_s=$runT
        uno_ms=$ut
        mode=$u.M
        traffic_state=$u.TS
        pred_x_cm=$u.KX;pred_y_cm=$u.KY;pred_heading_deg=$u.KH
        fused_x_cm=$u.X;fused_y_cm=$u.Y;fused_heading_deg=$u.H
        gyro_yaw_deg=$u.YA;gyro_available=$u.GY
        motor_left_pwm=$u.PL;motor_right_pwm=$u.PR
        line_left_adc=$u.L;line_middle_adc=$u.C;line_right_adc=$u.R
        green_confirmations=$u.GC
        estop_latched=$u.ES;estop_reason=$u.ER;fault_code=$u.FC
        search_phase=$u.SP
        red_seen=$redSeen;green_seen=$greenSeen;stop_sign_seen=$stopSeen
        telemetry_age_ms=$age;color_frame_age_ms=$status.vision_health.age_ms
        red_pixels=$r.pixels;green_pixels=$g.pixels
        red_x_px=$r.x;red_y_px=$r.y;green_x_px=$g.x;green_y_px=$g.y
        stop_x_px=$s.x;stop_y_px=$s.y;stop_width_px=$s.w;stop_image_w_px=$s.image_w
      }
      $row | Export-Csv -LiteralPath $poseCsv -NoTypeInformation -Append -Encoding UTF8
      $status | ConvertTo-Json -Depth 12 -Compress | Add-Content -LiteralPath $rawJsonl -Encoding UTF8
      $count++
      $eventKey = "$($u.TS)|$($u.ES)|$($u.FC)"
      if ($eventKey -ne $previousEvent) {
        [pscustomobject][ordered]@{
          pc_elapsed_s=$row.pc_elapsed_s;run_t_s=$runT;uno_ms=$ut
          event='STATE_OR_SAFETY_CHANGE';mode=$u.M;traffic_state=$u.TS
          fault_code=$u.FC;estop_latched=$u.ES;estop_reason=$u.ER
        } | Export-Csv -LiteralPath $eventsCsv -NoTypeInformation -Append -Encoding UTF8
        $previousEvent = $eventKey
      }
      if ($count -eq 1 -or $count % 10 -eq 0) {
        Write-Host "Saved $count rows | TS=$($u.TS) | E-stop=$($u.ES) | PWM=$($u.PL),$($u.PR)"
      }
    }
  } catch {
    $warningCount++
    if ($warningCount -le 3 -or $warningCount % 10 -eq 0) {
      Write-Warning "Cannot read fresh robot data: $($_.Exception.Message). Check Wi-Fi /traffic-status."
    }
  }
  Start-Sleep -Milliseconds $IntervalMs
}
$watch.Stop()
Write-Host "Finished; saved $count rows."
Write-Host "Pose:   $poseCsv"
Write-Host "Events: $eventsCsv"
Write-Host "Raw:    $rawJsonl"
if ($count -eq 0) { Write-Warning 'No telemetry recorded. Check laptop Wi-Fi and /traffic-status URL.' }
