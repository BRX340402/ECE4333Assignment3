ECE 4333 Assignment 3 -- Test 3 Windows telemetry logger (no Python required)

1. Download/extract this ZIP on Windows 10/11.
2. Connect the Windows laptop to the robot's Wi-Fi: ECE4333_A2_V2, password 12345678.
3. Confirm http://192.168.4.1/traffic-status opens and reports UNO UV=32 with a small top-level age_ms.
4. Double-click RUN_Test3_Logger_NoPython.bat. Recording begins immediately for 120 seconds.
   This does not control robot movement. Start/stop driving using the robot's web interface.
5. When the script completes, open run01_pose.csv and run01_events.csv with Excel.
6. For a quick 20-second run, open PowerShell in this folder and run:
   powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\Test3_Log_Without_Python.ps1 -Seconds 20 -Out quicktest
7. Note: Test 3 pose predictions are NOT real measured robot position. Compare with physical checkpoints separately.

Do not run untrusted PowerShell scripts. This script contacts only the local /traffic-status endpoint
and writes local files; it never sends movement/control requests to the robot.
