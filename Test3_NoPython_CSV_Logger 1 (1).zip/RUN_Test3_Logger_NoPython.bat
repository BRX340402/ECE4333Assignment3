@echo off
cd /d "%~dp0"
echo Connect this computer to ECE4333_A2_V2 Wi-Fi first.
echo The logger is read-only and does NOT start or stop the car.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Test3_Log_Without_Python.ps1" -Seconds 120 -Out run01
pause
