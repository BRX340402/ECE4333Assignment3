# ECE 4333 Assignment 3 — TEST 1

**Purpose:** Stabilize the previous V27 traffic + tracking project before adding emergency-stop, pose calibration, gyro/camera nested control or logging. This is NOT the complete Assignment 3 rubric solution.

## Provenance / rollback

- Base: `ECE4333_A3_red_green_120deg_FIXED(1).zip` (V27-style, UNO firmware `UV:26`).
- Source references: professor's ECE 4333 Assignment 3 instructions; ELEGOO Experiment 3 `Demo1.ino` sensor demo and `Demo2.ino` tracking demo. Both original demos are in `REFERENCE_ONLY_Experiment3`; **do not upload them with Test 1**.
- Test 1 uses the **same UART JSON protocol** as V27, with a new pairing marker `UV:31` to prevent mismatched flashing. `31` is a compatibility tag, not a historical 'V31' project.
- DO NOT merge UNO from another ZIP with this ESP32 or vice versa. Keep V27 ZIP untouched for rollback.

## Sketches to upload (separately)

1. `UNO_Assignment2/UNO_Assignment2.ino` → board **Arduino Uno**, car Upload selector as per ELEGOO. All supporting `.h` and `.cpp` files must remain in this folder.
2. `ESP32_Assignment2/ESP32_Assignment2.ino` → board **ESP32 Dev Module**, **Huge APP**, **PSRAM Enabled**, Flash 4MB, correct COM port and camera Upload/CAM selector as per ELEGOO. Keep ESP32 core / model library version compatible with your working build.
3. Return selector to **CAM/normal operation**, power-cycle with wheels safely lifted. Laptop Wi-Fi: `ECE4333_A2_V2`; password: `12345678`; dashboard: `http://192.168.4.1/traffic`; JSON: `http://192.168.4.1/traffic-status`.
4. Confirm dashboard title **Robot Car Test 1** and JSON `uno.UV == 31`, `age_ms < 1500`, `uno.TS == 0` before pressing Start.
5. Set **Stop on red, then scan for STOP = ON** (`RS:1`) and click Save; wait for **settings applied/UNO confirmed**.
6. Start with the slow V27 settings: **cruise PWM 50**, **reduced PWM 30**, **RA 120**, **SA 240**. Previously saved ESP32 settings override source defaults: inspect `settings` JSON before testing. The black sensor band is initially BL 600, BH 850 until measurements justify changing it.
7. Confirm a safe **STOP CAR** web button with wheels suspended. This build does **not** contain V29's remote emergency-stop latch. The legacy OK button sends a normal standby command; it is not a safety-rated E-stop. Keep physical battery switch accessible.

**Arduino libraries:** V27 source was prepared for FastLED 3.2.10 and Servo 1.2.2. New FastLED 3.10.7 + Servo 1.3.0 may fail with `multiple definition of __vector_11`; use the compatible versions packaged under `Arduino_Libraries/`. Model library `A2_StopSign_FOMO_104.zip` is also included. ESP32 `<atomic>` / `esp_jpg_decode.h` availability depends on compatible ESP32 board core; do not install random headers. IDE 2.x itself is fine.

## Test 1 expected runtime behavior

- Start follows the line immediately; green before red does **not** start or stop the car.
- `RS=1`: when a large enough red region appears, stop first in `VERIFY` and run STOP-sign inference while still. **No forward approach is attempted without validated distance calibration.** This is intentionally safer than creeping past a red light while classifying.
- STOP confirmed by two accepted AI results: remain stationary in `STOP_HOLD` **3000 ms**, then `CROSS` (moving). `CROSS` itself has separate minimum crossing time. Suppress retriggering the same red sign until **three valid red-free frames after returning to TRACK**.
- Red paper judged not STOP: `WAIT_RED` until **three distinct valid green-only frames**. Green can be **anywhere** in the frame; black/gray shouldn't be detected as green.
- Floor line lost: (phase 0) right ≤120°, (phase 1) sweep left ≤240°, (phase 2) return right ≤120°, (phase 3) one **100 ms at ≤PWM50** forward nudge only if fresh ultrasonic range is ≥22cm. If range unavailable (`-1`) **skip nudge** and proceed to next scan, not blindly move. Up to **five attempts**, also capped at ~55 seconds. Immediately exit search when black line is confirmed in 3 consecutive sensor readings. More precise actual angle and distance require robot calibration.
- All floor readings >950 are **no-line** rather than an assumed lift. The previous lift trigger gave a false `FAULT 7` on bright floor. This revision does **not** infer lifted status from those sensors. Do not run near tables/stairs or rely on floor sensors to protect against falls.

## Tests (in order)

1. **Compile UNO first**, then ESP32; code has passed *offline logic tests only*, **not** native board compilation or real robot movement tests. Check UNO flash/SRAM usage.
2. **Wheels off ground:** confirm STOP CAR, normal Start, telemetry firmware ID, phase and fault reporting. Use battery switch if unexpectedly moving.
3. **With car stationary:** red paper and green paper (light and dark) detection in browser. Verify red is seen without moving and that green is seen anywhere in the image. Then test AI STOP separately.
4. **Short floor line segment, large clear area:** at low PWM confirm BLACK sensor classification; only then test angular recovery. Log L/C/R sensor values and stop immediately if searching toward a hazard.
5. **Red traffic-light test:** show red while tracking; verify stationary VERIFY → WAIT_RED (after non-STOP AI) → green-only ×3 → TRACK.
6. **STOP-sign test:** stable, clearly visible sign → VERIFY → STOP_HOLD 3 s → CROSS. Do not assume a red rectangle guarantees model recognition.
7. If unwanted fault occurs, copy `http://192.168.4.1/traffic-status` JSON showing `uno.TS`, `uno.FC`, `uno.FS`, `uno.SE`, `uno.SP`, `uno.L/C/R`, `settings`, camera `vision_health` and `age_ms`.

## Floor sensor measurement (old Step 8)

Use **Robot OFF/standby** on the dashboard; leave battery power on so sensor telemetry continues. Don't click Start during sampling.

**Manual:** Connect laptop to ESP32 Wi-Fi, open `/traffic-status` and take three readings each with (a) floor sensors over ordinary light floor away from tape, (b) center sensor over black tape, and (c) robot lifted/secure. Copy `uno.L`, `uno.C`, `uno.R` for each condition to the supplied `PC_Diagnostics/floor_sensor_samples_TEMPLATE.csv`, then open it in Excel.

**Automatic:** If Python 3 is installed, open PowerShell in `PC_Diagnostics`, run `python record_floor_sensors.py` while connected to the robot's Wi-Fi. The script only GETs `/traffic-status`; it **never** sends motor commands. It prompts for three safe stationary positions, records 10 readings each and saves `floor_sensor_samples.csv` for Excel. Be careful with moving/lifting the powered car; switch off wheels/keep clear.

If white floor and lifted read similarly, the IR array cannot distinguish them; don't reinstate the old >950 fault without another sensor.

## Known limitations — honest test status

- This is a source-level prototype. ESP32/UNO compilation, timing and real motion are **not confirmed**. All turns are upper bounds; actual degrees depend on gyro sign/calibration and timing fallback.
- Green classification is tested on representative RGB values, **not** your camera's actual pixels or room lighting. A dark-green paper may still fail if below brightness threshold or if color balancing alters it.
- Wi-Fi preview and STOP inference can be slow; check frame age and classifier output. Color detection is still imperfect.
- Kinematic coefficients in this V27 base are zero and the gyroscope-gated `PoseEstimate` is not an accurate measured position. Logging/actual-trajectory comparison, camera fusion, robust target following, latched E-stop still need later work.
