# Test 1 changes against V27 baseline

Only these behavior modules changed. The baseline and bundled AI model/library archives are kept unmodified.

| File | Test 1 modification |
| --- | --- |
| `UNO_Assignment2/Ex3Tracking.h` | Third right-turn recovery phase, tiny forward ultrasonic-gated nudge, at most 5 attempts / 55s total. Treat all>950 as lost line, **not proven lift**. New `BLOCKED` reason. |
| `UNO_Assignment2/UNO_Assignment2.ino` | Pass actual sonar range to the recovery method. Map `BLOCKED` to `SEARCH_BLOCKED`. Add unique Test1 pairing firmware code `UV:31` in existing `N:221` telemetry. |
| `UNO_Assignment2/TrafficLogic.h` | Confirmed STOP in Stop-on-red mode holds 3s in `STOP_HOLD` before `CROSS`; lockout prevents repeated red sign immediately after crossing until 3 red-free TRACK frames. Preserve continuous Start behavior and green-only release. |
| `ESP32_Assignment2/RedDetector.h` | Introduce dedicated dark-green RGB classifier with low-brightness/saturation/dominance gates. |
| `ESP32_Assignment2/RedCamera.h` | **Actually call** the dedicated `greenPixel()` function; no red-as-green channel swapping. |
| `ESP32_Assignment2/ESP32_Assignment2.ino` | Send green detection independent of red's previous X location; require `UV=31` before allowing Start to prevent mixed firmware. Preserve camera, STOP model, and existing messaging. |
| `ESP32_Assignment2/TrafficPage.h` and generated `TrafficPageGzip.h` | Page explicitly titled Test 1; label four search phases / new fault; gzip regenerated from exact HTML. |
| `tests/test1_behavior.cpp` | New offline tests for traffic and recovery logic, including false lifted reading and obstacle-gated nudging. |
| `PC_Diagnostics/record_floor_sensors.py` | New optional read-only helper for sensor measurement CSV; no motion commands. |

Kept unchanged intentionally: slow V27 PWM defaults and saved-configuration system, camera AI model and core pipeline, original UART commands, Experiment 3 steering, normal Stop Car web behavior. No V29 or V30 features merged yet. Use `PATCH_FROM_V27_TO_TEST1.diff` for file-level evidence.
