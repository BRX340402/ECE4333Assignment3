# ECE 4333 Assignment 3 — Test 2 (deadline-focused green release)

## Purpose

This is Test 1 **with only two source files changed**, both on the Arduino UNO:

- `UNO_Assignment2/TrafficLogic.h`: While stopped in `VERIFY` (Stop-on-red mode) or `WAIT_RED`, require **2 distinct valid green-only observations within 6 seconds** to resume. A missing/invalid/no-green image no longer immediately wipes a partial green count; it expires after 6 seconds. A **valid red observation always resets** the green count. Because existing ESP32 messages distinguish any red region (`N=203`) from action-size red (`N=204.R`), Test 2 also treats recent `N=203` red as a red-signal priority during release. Remains stationary during STOP-sign 3-second hold.
- `UNO_Assignment2/UNO_Assignment2.ino`: uses the ESP32's existing `N=203` red-presence flag when deciding whether green may release a red-light wait. This catches smaller red regions that are below the normal `RP` stop-action threshold, even while a green-looking background is present. It also adds a diagnostic `GC` counter to the existing `N=221` telemetry (0 or 1 while waiting; resets to 0 when resuming). The ESP32 forwards the full telemetry message as `uno` in `/traffic-status`, so **the dashboard source doesn't need to change**.

**All ESP32 files, AI model, camera settings, motor commands, line-search algorithm, safety limits, and UNO UART protocol are exactly as in Test 1.** No camera-resolution change required to perform this trial.

## Upload (only UNO)

1. Keep the last working Test 1 ZIP as a backup.
2. In Arduino IDE, open `UNO_Assignment2/UNO_Assignment2.ino` **from this Test 2 folder**. Keep its `.h` and `.cpp` companion files alongside it.
3. Select **Arduino Uno**, choose the correct COM port, use the ELEGOO Upload mode, click **Verify** then **Upload**.
4. Return robot's selector to normal operating/CAM position according to the board labels. Do **not** upload the Test 2 ESP32 folder; it's an unchanged copy of Test 1. The firmware ID remains `UV=31`, so your existing ESP32 Test 1 continues to accept the UNO.
5. Connect to robot Wi-Fi `ECE4333_A2_V2`, open `http://192.168.4.1/traffic-status`. Confirm `uno.UV=31`, recent top-level `age_ms`, and **`uno.GC` appears**. If `GC` is absent, the UNO update didn't take effect.

## Quick safe test

1. Fully charge battery; test on a short black-line section in a clear floor area, with physical battery switch accessible. Keep slow `CS=50`, `DS=30` and `RS=1`.
2. With the robot driving at low speed, present RED until it stops and enters `VERIFY` (`TS=4`) or `WAIT_RED` (`TS=5`). Allow AI recognition to decide; a STOP sign triggers a 3-second stationary hold instead.
3. Remove RED completely. Hold a GREEN card centrally and steady for 8–10 seconds, ideally with a clip so fingers are outside camera view.
4. While GREEN is present, look at the UNO `GC` field in `/traffic-status` (refresh manually). You may see 0→1→0 when release succeeds (because the state transition clears the counter). The key sign of success is `TS` transitioning to `2` (TRACK).
5. The web dashboard will still say **Robot Car Test 1** because ESP32 code is deliberately unchanged. Use the new `uno.GC` field to verify Test 2 UNO.
6. **Important safety check**: with RED paper held steady (and with green-looking background objects), car must remain stopped; false green detections were previously observed with red paper. If it resumes on RED, stop testing and restore Test 1.
7. If it still waits, capture a single `/traffic-status` JSON showing `vision_health`, `objects.red`, `objects.green`, and `uno.TS`, `uno.GC` before revising anything else.

## Scope, limitations and safety

- This patch does **not** fully solve false green detections. It uses the ESP32's existing `N=203` recent-any-red report to block release while a small red region is still visible, in addition to the existing `N=204` action-sized red flag. In prior data the ESP32 sometimes classified large areas as green even with red paper present, so the mandatory **red-only hold test** is critical.
- `GC` is an observation counter, not the camera's `green_regions`. The latter is a count of image regions, not UNO confirmations.
- The 6-second window uses separate valid camera frames (incremented `S` sequence numbers), never reuses an identical frame.
- Faster release isn't guaranteed, since the ESP32 can still have long camera frame intervals; no unsupported claim of real hardware validation is made.
- No native Arduino UNO compilation or physical motion has been performed in this environment. Host-only state-machine tests passed.
- Known weak right-side wheel remains a separate motor/power issue. Avoid long autonomous runs until it is diagnosed.
- This update does not add kinematics, emergency-stop latch, or CSV logging. Those are still pending after green-light behavior is verified.
